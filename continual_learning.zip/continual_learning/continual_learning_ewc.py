N_EXPERIENCES = 40

import os
import torch
from torch import nn
from torchvision import datasets, transforms
from torch.utils.data import DataLoader, Subset
from avalanche.benchmarks import nc_benchmark
from avalanche.training.supervised import EWC
from avalanche.training.plugins import EvaluationPlugin
from avalanche.evaluation.metrics import accuracy_metrics, loss_metrics, forgetting_metrics
from avalanche.logging import InteractiveLogger
from itertools import product
import time
from collections import Counter
import numpy as np

# Define a custom MLP model
class CustomMLP(nn.Module):
    def __init__(self, num_classes):
        super(CustomMLP, self).__init__()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(100*100*3, 512)  # Correct input size for 100x100 RGB images
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(512, 512)
        self.fc3 = nn.Linear(512, num_classes)
    
    def forward(self, x):
        x = self.flatten(x)
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.relu(x)
        x = self.fc3(x)
        return x

# Set the paths
dataset_path = 'learn2learn_on_fruit/data/dataset'  # Replace with the path to your dataset

# Define a simple transformation to normalize the images
transform = transforms.Compose([
    transforms.Resize((100, 100)),
    transforms.ToTensor(),
])

# Load the dataset
full_dataset = datasets.ImageFolder(root=dataset_path, transform=transform)
class_names = full_dataset.classes
print("DONE")
# Split the dataset such that there are only 5 examples per class for training and 5 for testing
def split_dataset(dataset, n_train, n_test):
    targets = np.array([s[1] for s in dataset.samples])
    train_indices = []
    test_indices = []

    for class_idx in range(len(dataset.classes)):
        class_indices = np.where(targets == class_idx)[0]
        np.random.shuffle(class_indices)
        train_indices.extend(class_indices[:n_train])
        test_indices.extend(class_indices[n_train:n_train + n_test])

    train_subset = Subset(dataset, train_indices)
    test_subset = Subset(dataset, test_indices)

    return train_subset, test_subset

train_dataset, test_dataset = split_dataset(full_dataset, n_train=5, n_test=5)

# Print number of examples per class in train_dataset and test_dataset
def count_classes(dataset):
    targets = [s[1] for s in dataset]
    return Counter(targets)

train_class_counts = count_classes(train_dataset)
test_class_counts = count_classes(test_dataset)

print("Train Dataset Class Counts:")
for class_idx, count in train_class_counts.items():
    print(f"{class_names[class_idx]}: {count}")

print("\nTest Dataset Class Counts:")
for class_idx, count in test_class_counts.items():
    print(f"{class_names[class_idx]}: {count}")

# Create the continual learning scenario
scenario = nc_benchmark(train_dataset, test_dataset, n_experiences=N_EXPERIENCES, shuffle=False, task_labels=True)
print("DONE")
# Print class names and number of examples per class for each experience
def print_experience_info(stream, stream_name):
    for experience in stream:
        print(f"\n{stream_name} Experience {experience.current_experience}:")
        class_counts = Counter(experience.dataset.targets)
        for class_idx, count in class_counts.items():
            print(f"{class_names[class_idx]}: {count}")

print_experience_info(scenario.train_stream, "Train Stream")
print_experience_info(scenario.test_stream, "Test Stream")

# Define the parameter grid
ewc_lambdas = [0.1, 1.0]
train_mb_sizes = [32, 64]
train_epochs_list = [10, 20]
eval_mb_sizes = [32, 64]

# Create the results directory
results_dir = 'results'
if not os.path.exists(results_dir):
    os.makedirs(results_dir)

# Grid search
for ewc_lambda, train_mb_size, train_epochs, eval_mb_size in product(ewc_lambdas, train_mb_sizes, train_epochs_list, eval_mb_sizes):
    # Define the model
    start_time = time.time()
    model = CustomMLP(num_classes=scenario.n_classes)

    # Define the strategy
    interactive_logger = InteractiveLogger()
    evaluation_plugin = EvaluationPlugin(
        accuracy_metrics(minibatch=True, epoch=True, experience=True, stream=True),
        loss_metrics(minibatch=True, epoch=True, experience=True, stream=True),
        forgetting_metrics(experience=True, stream=True),
        loggers=[interactive_logger]
    )

    strategy = EWC(
        model=model,
        optimizer=torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9),
        criterion=torch.nn.CrossEntropyLoss(),
        ewc_lambda=ewc_lambda,
        train_mb_size=train_mb_size,
        train_epochs=train_epochs,
        eval_mb_size=eval_mb_size,
        device='cpu',
        evaluator=evaluation_plugin
    )

    # Create a directory for this parameter set
    param_dir = os.path.join(results_dir, f'ewc_lambda_{ewc_lambda}_trainmb_{train_mb_size}_epochs_{train_epochs}_evalmb_{eval_mb_size}')
    if not os.path.exists(param_dir):
        os.makedirs(param_dir)

    # File to save results
    results_file = os.path.join(param_dir, 'results.txt')

    total_accuracies = []
    # Training loop
    with open(results_file, 'w+') as f:
        for experience in scenario.train_stream:
            print(f"Start training on experience {experience.current_experience}")
            train_results = strategy.train(experience)
            print(f"End training on experience {experience.current_experience}")
            
            print("Computing accuracy on the test set")
            eval_results = strategy.eval(scenario.test_stream)

            # Log the accuracy on all test experiences
            all_accuracies = []
            for exp in scenario.test_stream:
                curr = exp.current_experience
                if curr < 10:
                    accuracy = eval_results[f'Top1_Acc_Exp/eval_phase/test_stream/Task00{curr}/Exp00{curr}']
                else:
                    accuracy = eval_results[f'Top1_Acc_Exp/eval_phase/test_stream/Task0{curr}/Exp0{curr}']
                    
                all_accuracies.append(accuracy)

            total_accuracies.append(all_accuracies)
            print(f"#########################ALL ACCURACIES: {all_accuracies}############################")
            f.write(' '.join(format(x, '.3f') for x in all_accuracies))
            f.write('\n')

    
        till_task_accuracy = []
        for i in range(len(total_accuracies)):
            sm = 0
            for j in range(i+1):
                sm += total_accuracies[i][j]

            till_task_accuracy.append(sm/(i+1))

        f.write("#########################TILL TASK ACCURACIES:############################")
        f.write(' '.join(format(x, '.3f') for x in till_task_accuracy))
    

    end_time = time.time()
    print(f"Execution Time: {end_time-start_time} in seconds")
